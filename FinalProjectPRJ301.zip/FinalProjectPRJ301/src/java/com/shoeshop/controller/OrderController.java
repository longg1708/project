package com.shoeshop.controller;

import com.shoeshop.dao.OrderDAO;
import com.shoeshop.model.Order;
import com.shoeshop.model.User;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Controller for orders
 */
@WebServlet(name = "OrderController", urlPatterns = {"/checkout", "/orders", "/order-history"})
public class OrderController extends HttpServlet {
    private OrderDAO orderDAO;
    
    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAO();
    }
    
    /**
     * Handles the HTTP <code>GET</code> method.
     * Displays checkout, order details, or order history
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String path = request.getServletPath();
        
        try {
            if ("/checkout".equals(path)) {
                // Display checkout page
                request.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(request, response);
            } else if ("/orders".equals(path)) {
                // Display order details
                String orderIdParam = request.getParameter("id");
                
                if (orderIdParam != null && !orderIdParam.isEmpty()) {
                    int orderId = Integer.parseInt(orderIdParam);
                    Order order = orderDAO.findById(orderId);
                    
                    if (order == null || (order.getUserId() != user.getId() && !user.isAdmin())) {
                        response.sendRedirect(request.getContextPath() + "/order-history");
                        return;
                    }
                    
                    request.setAttribute("order", order);
                    request.getRequestDispatcher("/WEB-INF/views/orderDetail.jsp").forward(request, response);
                } else {
                    response.sendRedirect(request.getContextPath() + "/order-history");
                }
            } else if ("/order-history".equals(path)) {
                // Display order history
                List<Order> orders;
                
                if (user.isAdmin()) {
                    // Admins can see all orders
                    orders = orderDAO.findAll();
                } else {
                    // Regular users see only their orders
                    orders = orderDAO.findByUserId(user.getId());
                }
                
                request.setAttribute("orders", orders);
                request.getRequestDispatcher("/WEB-INF/views/ordersHistory.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/home");
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/order-history");
        }
    }
    
    /**
     * Handles the HTTP <code>POST</code> method.
     * Processes order creation
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String path = request.getServletPath();
        
        if ("/checkout".equals(path)) {
            // Process checkout
            try {
                String shippingAddress = request.getParameter("shippingAddress");
                String paymentMethod = request.getParameter("paymentMethod");
                
                if (shippingAddress == null || shippingAddress.isEmpty() || 
                    paymentMethod == null || paymentMethod.isEmpty()) {
                    
                    request.setAttribute("errorMessage", "All fields are required!");
                    request.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(request, response);
                    return;
                }
                
                // Create order from cart
                Order order = orderDAO.createOrderFromCart(user.getId(), shippingAddress, paymentMethod);
                
                // Set success message
                session.setAttribute("successMessage", "Order placed successfully! Order ID: " + order.getId());
                
                // Redirect to order history
                response.sendRedirect(request.getContextPath() + "/order-history");
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("errorMessage", "Error placing order: " + e.getMessage());
                request.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(request, response);
            }
        }
    }
}
