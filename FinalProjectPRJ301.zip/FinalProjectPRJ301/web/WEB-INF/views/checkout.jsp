<%@ page pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<div class="container">
    <h1 class="mb-4">Checkout</h1>
    
    <c:choose>
        <c:when test="${not empty cart && not empty cart.items}">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Shipping Information</h5>
                        </div>
                        <div class="card-body">
                            <form action="${pageContext.request.contextPath}/checkout" method="post" id="checkoutForm">
                                <div class="mb-3">
                                    <label for="shippingAddress" class="form-label">Shipping Address*</label>
                                    <textarea class="form-control" id="shippingAddress" name="shippingAddress" rows="3" required>${sessionScope.user.address}</textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Payment Method*</label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="creditCard" value="Credit Card" checked>
                                        <label class="form-check-label" for="creditCard">
                                            <i class="fab fa-cc-visa me-2"></i>Credit Card
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="paypal" value="PayPal">
                                        <label class="form-check-label" for="paypal">
                                            <i class="fab fa-paypal me-2"></i>PayPal
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="cod" value="Cash on Delivery">
                                        <label class="form-check-label" for="cod">
                                            <i class="fas fa-money-bill-wave me-2"></i>Cash on Delivery
                                        </label>
                                    </div>
                                </div>
                                
                                <div id="creditCardDetails">
                                    <div class="row">
                                        <div class="col-md-8 mb-3">
                                            <label for="cardNumber" class="form-label">Card Number</label>
                                            <input type="text" class="form-control" id="cardNumber" placeholder="1234 5678 9012 3456">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="cardCvv" class="form-label">CVV</label>
                                            <input type="text" class="form-control" id="cardCvv" placeholder="123">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="cardExpiry" class="form-label">Expiration Date</label>
                                            <input type="text" class="form-control" id="cardExpiry" placeholder="MM/YY">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="cardName" class="form-label">Name on Card</label>
                                            <input type="text" class="form-control" id="cardName">
                                        </div>
                                    </div>
                                    <div class="alert alert-info" role="alert">
                                        <small><i class="fas fa-info-circle me-2"></i>Credit card information is not stored. This is for demonstration purposes only.</small>
                                    </div>
                                </div>
                                
                                <div class="d-grid mt-4">
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-check-circle me-2"></i>Place Order
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="card cart-summary mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Order Summary</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal (${cart.totalItems} items)</span>
                                <span>$<fmt:formatNumber value="${cart.totalPrice}" pattern="#,##0.00"/></span>
                            </div>
                            
                            <div class="d-flex justify-content-between mb-2">
                                <span>Shipping</span>
                                <span>Free</span>
                            </div>
                            
                            <hr>
                            
                            <div class="d-flex justify-content-between mb-4">
                                <strong>Total</strong>
                                <strong class="product-price">$<fmt:formatNumber value="${cart.totalPrice}" pattern="#,##0.00"/></strong>
                            </div>
                            
                            <div class="card bg-light mb-3">
                                <div class="card-body py-2">
                                    <h6 class="mb-3">Items in Your Order</h6>
                                    <c:forEach var="item" items="${cart.items}">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div>
                                                <span>${item.product.name}</span>
                                                <small class="text-muted d-block">Qty: ${item.quantity}</small>
                                            </div>
                                            <span>$<fmt:formatNumber value="${item.subtotal}" pattern="#,##0.00"/></span>
                                        </div>
                                    </c:forEach>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-shield-alt fa-2x text-success me-3"></i>
                                <div>
                                    <h6 class="mb-0">Secure Checkout</h6>
                                    <small class="text-muted">Your payment information is secure</small>
                                </div>
                            </div>
                            
                            <div class="d-flex align-items-center">
                                <i class="fas fa-truck fa-2x text-primary me-3"></i>
                                <div>
                                    <h6 class="mb-0">Free Shipping</h6>
                                    <small class="text-muted">On all orders</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </c:when>
        <c:otherwise>
            <div class="alert alert-warning" role="alert">
                Your cart is empty. You cannot proceed to checkout.
                <a href="${pageContext.request.contextPath}/home" class="alert-link">Click here</a> to continue shopping.
            </div>
        </c:otherwise>
    </c:choose>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Show/hide credit card details based on payment method selection
        const paymentRadios = document.querySelectorAll('input[name="paymentMethod"]');
        const creditCardDetails = document.getElementById('creditCardDetails');
        
        paymentRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.id === 'creditCard') {
                    creditCardDetails.style.display = 'block';
                } else {
                    creditCardDetails.style.display = 'none';
                }
            });
        });
        
        // Form validation
        const checkoutForm = document.getElementById('checkoutForm');
        checkoutForm.addEventListener('submit', function(event) {
            const shippingAddress = document.getElementById('shippingAddress').value.trim();
            
            if (!shippingAddress) {
                event.preventDefault();
                alert('Please enter a shipping address');
                return false;
            }
            
            // If credit card is selected, validate card details
            const creditCardRadio = document.getElementById('creditCard');
            if (creditCardRadio.checked) {
                const cardNumber = document.getElementById('cardNumber').value.trim();
                const cardCvv = document.getElementById('cardCvv').value.trim();
                const cardExpiry = document.getElementById('cardExpiry').value.trim();
                const cardName = document.getElementById('cardName').value.trim();
                
                // This is just a basic validation for demonstration
                // In a real app, you'd want more sophisticated validation
                if (!cardNumber || !cardCvv || !cardExpiry || !cardName) {
                    // In this demo, we'll allow the form to submit anyway
                    // since we're not actually processing payments
                    console.log('Card details not complete, but continuing for demo purposes');
                }
            }
        });
    });
</script>
